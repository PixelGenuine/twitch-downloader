chrome.runtime.onInstalled.addListener(function() {
    window.alert("Thank you for installing Twitch Downloader <3");
});

